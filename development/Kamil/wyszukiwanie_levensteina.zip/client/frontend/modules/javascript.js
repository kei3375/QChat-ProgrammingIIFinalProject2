// toggle active friend on click
document.querySelectorAll('.friend-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.friend-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
  });
});

let friend_uuid = "$$selected uuid$$";

// ===================================================
// STAN WYSZUKIWANIA — globalna zmienna pamiętana
// między odświeżeniami readAllMessages()
// ===================================================
let aktywneWyszukiwanie = '';

function zastosujFiltr() {
  if (aktywneWyszukiwanie === '') return;

  document.querySelectorAll('.msg-row').forEach(function(wiersz) {
    const dymki = wiersz.querySelectorAll('.msg-bubble');
    let wierszPasuje = false;

    dymki.forEach(function(dymek) {
      dymek.classList.remove('search-highlight');
      const tekstDymka = dymek.textContent.toLowerCase();
      const slowaWiadomosci = tekstDymka.split(/\s+/);
      let dymekPasuje = false;

      for (let i = 0; i < slowaWiadomosci.length; i++) {
        if (liczLevenshteina(aktywneWyszukiwanie, slowaWiadomosci[i]) <= 2) {
          dymekPasuje = true;
          break;
        }
      }

      if (dymekPasuje) {
        dymek.classList.add('search-highlight');
        wierszPasuje = true;
      }
    });

    wiersz.style.display = wierszPasuje ? '' : 'none';
  });
}

async function readAllMessages() {
  const response = await fetch(`/messages/${friend_uuid}`);
  const messages = await response.json();
  const area = document.querySelector('.messages-area');
  const old = area.innerHTML;
  area.innerHTML = '';

  messages.forEach(msg => {
    const row = document.createElement('div');
    row.className = msg.sender === 'you' ? 'msg-row mine' : 'msg-row';
    row.innerHTML = `
      <div class="msg-avatar">${msg.sender === 'you' ? '<img src="/profile_picture.jpg" width="30" class="pfp"></img>' : '<img src="/pfps/'+friend_uuid+'" width="30" class="pfp"></img>'}</div>
      <div class="msg-bubble-group">
        <div class="msg-bubble">${msg.message.replace(/</g,'&lt;')}</div>
        <div class="msg-time">${msg.time.slice(0, 5)}</div>
      </div>`;
    area.prepend(row);
  });

  // Po zbudowaniu DOM — od razu aplikuj aktywny filtr jeśli istnieje.
  // Bez tego każde odświeżenie (co 125ms) niszczyło wyniki wyszukiwania.
  zastosujFiltr();

  if(area.innerHTML != old) {area.scrollTop = area.scrollHeight;}
}


async function send_message(uuid, message) {
  await fetch("/send/" + uuid, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: message })
  });

  loadFriendList();
}


// send on Enter
document.querySelector('.input-wrap input').addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.value.trim()) {
    const area = document.querySelector('.messages-area');
    send_message(friend_uuid, e.target.value);
    readAllMessages();
    area.scrollTop = area.scrollHeight;
    e.target.value = '';
  }
});

// send button
document.querySelector('.send-btn').addEventListener('click', () => {
  const input = document.querySelector('.input-wrap input');
  if (input.value.trim()) {
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  }
});


async function select_user(uuid, username) {
  await fetch("/select_user/"+uuid);
  friend_uuid = uuid;

  readAllMessages();
  loadFriendList();
  document.getElementById("chat-header-pfp").innerHTML = `<img src="pfps/${uuid}" width="40"></img>`;
  document.getElementById("chat-header-username").innerHTML = username;
}


async function loadFriendList() {
  const response = await fetch(`/friend_list`);
  const friends = await response.json();
  const area = document.querySelector('.friend-list');
  area.innerHTML = '';
  
  friends.sort((a, b) => {
    const dateA = new Date((a.last_message_date || "0") + " " + (a.last_message_time || "0"));
    const dateB = new Date((b.last_message_date || "0") + " " + (b.last_message_time || "0"));
    return dateB - dateA;
  });

  friends.forEach(usr => {
    const row = document.createElement('div');
    row.className = usr.selected === 'true' ? 'friend-item active' : 'friend-item';
    row.onclick = () => select_user(usr.uuid, usr.username);

    row.innerHTML = `
      <div class="friend-avatar pfp">
          <img src="/pfps/${usr.uuid}" width="40"></img>
          ${''}
      </div>
      <div class="friend-info">
          <div class="friend-name">${usr.username}</div>
          <div class="friend-preview">${usr.last_message}</div>
      </div>
      <div class="friend-meta">
          ${usr.notifications!='0'?'<span class="unread-badge">'+ usr.notifications + '</span>':''}
      </div>
    ${''}`;
    area.appendChild(row);
  });
}


//load everything
loadFriendList();
readAllMessages();

setInterval(function(){readAllMessages();},125);


// ===================================================
// ALGORYTM LEVENSHTEINA
// ===================================================
function liczLevenshteina(slowoA, slowoB) {
    if (slowoA.length === 0) return slowoB.length;
    if (slowoB.length === 0) return slowoA.length;

    const macierz = [];

    for (let i = 0; i <= slowoB.length; i++) macierz[i] = [i];
    for (let j = 0; j <= slowoA.length; j++) macierz[0][j] = j;

    for (let i = 1; i <= slowoB.length; i++) {
        for (let j = 1; j <= slowoA.length; j++) {
            if (slowoB.charAt(i - 1) === slowoA.charAt(j - 1)) {
                macierz[i][j] = macierz[i - 1][j - 1];
            } else {
                macierz[i][j] = Math.min(
                    macierz[i - 1][j - 1] + 1,
                    Math.min(
                        macierz[i][j - 1] + 1,
                        macierz[i - 1][j] + 1
                    )
                );
            }
        }
    }
    return macierz[slowoB.length][slowoA.length];
}

// ===================================================
// WYSZUKIWANIE — podpięcie pod pasek
// Przeniesione do DOMContentLoaded żeby mieć pewność
// że .topbar-search już istnieje w DOM w momencie
// wykonania querySelector (wcześniej zwracał null).
// ===================================================
document.addEventListener('DOMContentLoaded', function() {
  const poleWyszukiwania = document.querySelector('.op-search input');
  if (!poleWyszukiwania) return;

  poleWyszukiwania.addEventListener('keydown', function(zdarzenie) {
    if (zdarzenie.key === 'Enter') {
      aktywneWyszukiwanie = poleWyszukiwania.value.toLowerCase().trim();
      zastosujFiltr();
    }
  });

  // Reset gdy pole wyczyszczone
  poleWyszukiwania.addEventListener('input', function() {
    if (poleWyszukiwania.value === '') {
      aktywneWyszukiwanie = '';
      document.querySelectorAll('.msg-row').forEach(wiersz => {
        wiersz.style.display = '';
        wiersz.querySelectorAll('.msg-bubble').forEach(b => b.classList.remove('search-highlight'));
      });
    }
  });
});