#pragma once

#include <iostream>
#include <string>

std::string htmlentities(std::string html) {
    std::string result;
    result.reserve(html.size());

    for (unsigned char c : html) {
        switch (c) {
            case '&':  result += "&amp;";  break;
            case '<':  result += "&lt;";   break;
            case '>':  result += "&gt;";   break;
            case '"':  result += "&quot;"; break;
            case '\'': result += "&#39;";  break;
            default:
                if (c > 127) {
                    result += "&#";
                    result += std::to_string(c);
                    result += ';';
                } else {
                    result += c;
                }
        }
    }

    return result;
}




// chat.cpp
// author valerie
// there is no license

#include <array>
#include <ctime>
#include <functional>
#include <iostream>
#include <memory>
#include <string>
#include <asio.hpp>
#include <conio.h>


using asio::ip::udp;

// std::string target_ip;
// int iport;
// int oport;





// int main(int argc, char const *argv[])
// {
//   try
//   {
//     if (argc != 4) {
//         std::cerr << "Usage: client <host> <receiver port> <sender port>" << std::endl;
//         return 1;
//     } else {
//         target_ip = argv[1];
//         iport = std::stoi(argv[2]);
//         oport = std::stoi(argv[3]);
//     }
//     updateUI();
//     asio::io_context io_context;
//     udp_server server(io_context, iport, oport);
//     // server.send("hello\n  meow meow\n 1000000000001");
//     std::string mssg;
//     // while(1) {
//     //     getline(std::cin, mssg);
//     //     server.sync_send(mssg);
//     // }
//     io_context.run();
//   }
//   catch (std::exception& e)
//   {
//     std::cerr << e.what() << std::endl;
//   }
//   return 0;
// }