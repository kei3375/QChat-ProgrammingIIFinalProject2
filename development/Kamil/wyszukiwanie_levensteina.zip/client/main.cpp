// 
// 
// 
// copyright kei3375 on github
// and others (c)
// 
// 
// 
// 
// 
// 



#include <iostream>
#include <asio.hpp>
#include <vector>
#include <fstream>
#include <array>
#include <string>

#include "QLib.hpp"



using asio::ip::tcp;
using asio::ip::udp;


std::string qindex = "./frontend/index.html";
std::string style = "./frontend/style.css";
std::string options = "./frontend/modules/options.html";
std::string input_bar = "./frontend/modules/input_bar.html";
std::string javascript = "./frontend/modules/javascript.js";
std::string messages_module = "./frontend/modules/messages.html";
std::string  chat_header = "./frontend/modules/chat_header.html";
std::string friend_list = "./frontend/modules/friend_list.html";
std::string top_bar = "./frontend/modules/top_bar.html";
// std::string  = "./frontend/modules/.html";
std::string meow = "./frontend/meow.txt";


std::string icon = "./frontend/icon.ico";
std::string logo = "./frontend/logo.jpg";

std::string uuid="";

std::string username = "./user_settings/name.txt";
std::string profile_picture = "./user_settings/profile_picture.jpg";

int client_port = 80;

// udp_server udp_connection1;

std::string selected_user = "f47ac10b-58cc-4372-a567-0e02b2c3d479";


// class user {     //will be used later // maybe
// public:

//     std::string uuid;
//     bool is_online;

//     user() {
//         is_online = false;
//     }
//     user(std::string _uuid) :
//         uuid(_uuid)
//     {
//         is_online = false;
//     }
// };



std::string replace_string_pattern_with(std::string source, const std::string& pattern1, const std::string& string2) {//gemini generated function
    if (pattern1.empty()) return source; // Prevent infinite loop if pattern1 is empty
    
    size_t start_pos = 0;
    while ((start_pos = source.find(pattern1, start_pos)) != std::string::npos) {
        source.replace(start_pos, pattern1.length(), string2);
        // Move start_pos forward so we don't accidentally replace inside the newly inserted string
        start_pos += string2.length(); 
    }

    return source;
}

std::string make_json_messages(std::string req_uuid) {
    std::string location = "./friends/"+req_uuid+"/messages.txt";
    std::ifstream file(location);
    if (!file.is_open()) return "[]";

    std::string result = "[";
    std::string line;
    bool first = true;

    while (std::getline(file, line)) {
        std::string sender = "";
        if (line == "$friend") sender = req_uuid;
        // else if (line == "$you") sender = uuid;
        else if (line == "$you") sender = "you";
        else continue;

        std::string message, date, time_str;

        while (std::getline(file, line) && line != "$end") {
            if (line.rfind("message:", 0) == 0) message  = line.substr(8);
            else if (line.rfind("date:",   0) == 0) date = line.substr(5);
            else if (line.rfind("time:",   0) == 0) time_str = line.substr(5);
        }

        if (!first) result += ",";
        first = false;

        result += "{";
        result += "\"sender\":\"" + sender + "\",";
        result += "\"message\":\"" + message + "\",";
        result += "\"date\":\"" + date + "\",";
        result += "\"time\":\"" + time_str + "\"";
        result += "}";
    }

    result += "]";
    file.close();
    return result;
}
#include <string>
#include <fstream>
#include <filesystem>

namespace fs = std::filesystem;

std::string make_json_friends() {
    std::string friends_path = "./friends";
    
    // Sprawdzenie, czy katalog główny istnieje
    if (!fs::exists(friends_path) || !fs::is_directory(friends_path)) {
        return "[]";
    }

    std::string result = "[";
    bool first = true;

    // Iteracja po wszystkich elementach w katalogu ./friends
    for (const auto& entry : fs::directory_iterator(friends_path)) {
        if (entry.is_directory()) {
            std::string uuid = entry.path().filename().string();
            
            // 1. Odczyt username z ./friends/[uuid]/username.txt
            std::string username_path = entry.path().string() + "/username.txt";
            std::ifstream user_file(username_path);
            std::string username = "";
            if (user_file.is_open()) {
                std::getline(user_file, username);
                user_file.close();
            } else {
                // Jeśli nie można odczytać pliku użytkownika, pomijamy ten katalog
                continue; 
            }

            // 2. Odczyt ostatniej wiadomości z ./friends/[uuid]/messages.txt
            std::string messages_path = entry.path().string() + "/messages.txt";
            std::ifstream msg_file(messages_path);
            std::string last_message = "";
            std::string last_message_date = "";
            std::string last_message_time = "";
            if (msg_file.is_open()) {
                std::string line;
                // Przechodzimy przez cały plik i nadpisujemy zmienną, 
                // dzięki czemu na końcu zostanie w niej ostatnia linijka z "message:"
                while (std::getline(msg_file, line)) {
                    if (line.rfind("message:", 0) == 0) {
                        last_message = line.substr(8);
                    }
                    if (line.rfind("date:", 0) == 0) {
                        last_message_date = line.substr(5);
                    }
                    if (line.rfind("time:", 0) == 0) {
                        last_message_time = line.substr(5);
                    }
                }
                msg_file.close();
            }

            // Formatowanie JSON (ręczne składanie stringa, tak jak w make_json_messages)
            if (!first) result += ",";
            first = false;

            result += "{";
            result += "\"uuid\":\"" + uuid + "\",";
            result += "\"username\":\"" + username + "\",";
            result += "\"last_message\":\"" + last_message + "\",";
            result += "\"last_message_date\":\"" + last_message_date + "\",";
            result += "\"last_message_time\":\"" + last_message_time + "\",";
            
            // Domyślne wartości dla pól wymaganych przez frontend
            if(selected_user == uuid)
                result += "\"selected\":\"true\",";     // Skrypt JS sprawdza usr.selected === 'true'
            else
                result += "\"selected\":\"false\",";     // Skrypt JS sprawdza usr.selected === 'true'
            result += "\"status\":\"online\",";       // Klasa CSS: status-dot online
            result += "\"unread\":\"false\",";       // Informacja o nieprzeczytanych wiadomościach
            result += "\"notifications\":\"0\"";     // Liczba powiadomień
            result += "}";
        }
    }

    result += "]";
    return result;
}

std::string read_file(std::string filename) { //ai generated function to read from ./index.html file
    // Open the file at the end (ios::ate) and in binary mode
    // std::string filename = "./index.html";
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }

    // Get the current position (which is the file size)
    std::streamsize size = file.tellg();
    
    // Move back to the beginning of the file to start reading
    file.seekg(0, std::ios::beg);

    // Allocate the string with the correct size
    std::string contents(size, '\0');

    // Read the file data into the string's buffer
    if (!file.read(&contents[0], size)) {
        throw std::runtime_error("Error reading file: " + filename);
    }

    return contents;
}

std::string prepare_html(std::string html) {
    html = replace_string_pattern_with(html, "$$javascript$$", read_file(javascript));    //javascript u góry bo jest tam używana zmienna $$selected uuid$$
    html = replace_string_pattern_with(html, "$$messages$$", read_file(messages_module));
    html = replace_string_pattern_with(html, "`$`meow meow`$`", read_file(meow));
    html = replace_string_pattern_with(html, "$$options$$", read_file(options));
    html = replace_string_pattern_with(html, "$$input bar$$", read_file(input_bar));
    html = replace_string_pattern_with(html, "$$chat header$$", read_file(chat_header));
    html = replace_string_pattern_with(html, "$$friend list$$", read_file(friend_list));
    html = replace_string_pattern_with(html, "$$top bar$$", read_file(top_bar));
    html = replace_string_pattern_with(html, "$$username$$", read_file(username));
    html = replace_string_pattern_with(html, "$$uuid$$", uuid);
    html = replace_string_pattern_with(html, "$$selected uuid$$", selected_user);
    html = replace_string_pattern_with(html, "$$selected user username$$", read_file("./friends/"+selected_user+"/username.txt"));
    return html;
}

std::string make_daytime_string()       //for debugging / testing ?? delete later
{
  using namespace std; // For time_t, time and ctime;
  time_t now = time(0);
  return ctime(&now);
}

std::string make_http_response(const std::string& body, const std::string& content_type) {
    std::string res;
    res += "HTTP/1.1 200 OK\r\n";
    res += "Content-Type: " + content_type + "\r\n";
    res += "Content-Length: " + std::to_string(body.size()) + "\r\n";
    res += "Access-Control-Allow-Origin: *\r\n";
    res += "Connection: close\r\n";
    res += "\r\n";
    res += body;
    return res;
}

void save_message(std::string requested_uuid, std::string message, std::string who) {
    // pobierz aktualną datę i czas
        std::time_t t = std::time(nullptr);
        std::tm* tm = std::localtime(&t);
        char date[11], time_str[9];
        std::strftime(date, sizeof(date), "%Y-%m-%d", tm);
        std::strftime(time_str, sizeof(time_str), "%H:%M:%S", tm);
        
        // zapisz do pliku
        std::ofstream file("friends/" + requested_uuid + "/messages.txt", std::ios::app);
        file << "\n$"+who+"\n";
        file << "message:" << message << "\n";
        file << "date:" << date << "\n";
        file << "time:" << time_str << "\n";
        file << "$end\n";
        file.close();
}






class udp_server
{
    asio::io_context * io;
    udp::socket socket;
    udp::endpoint remote_endpoint;
    udp::endpoint send_endpoint;
    std::array<char, 512> recv_buffer;
    asio::steady_timer t_udp_punch;
public:
    udp_server(asio::io_context& io_context, int iport, int oport, std::string ip_address)
    : socket(io_context, udp::endpoint(udp::v4(), iport)), t_udp_punch(io_context, asio::chrono::milliseconds(1))
    {
        io = &io_context;
        udp::resolver res(io_context);
        // kbd_t = asio::steady_timer(io_context, asio::chrono::milliseconds(1));
        send_endpoint = *res.resolve(udp::v4(), ip_address, std::to_string(oport)).begin();
        start_receive();
        udp_punch(&t_udp_punch);

        std::fill_n(recv_buffer.begin(), 64, 0); // clear shit
    }
    
    void change_target(int iport, int oport, std::string ip_addr) {
        socket.close();
        socket = udp::socket(*io, udp::endpoint(udp::v4(), iport));
        // kbd_t(io_context, asio::chrono::milliseconds(1)), 
        // t_udp_punch(io_context, asio::chrono::milliseconds(1))
        udp::resolver res(*io);
        send_endpoint = *res.resolve(udp::v4(), ip_addr, std::to_string(oport)).begin();
        // start_receive();
        // udp_punch(&t_udp_punch);

        std::cout<<iport<<"\n"<<oport<<"\n"<<ip_addr<<std::endl;
    
        std::fill_n(recv_buffer.begin(), 64, 0); // clear shit

    }

    void udp_punch(asio::steady_timer * t) {

        send("");

        t->expires_at(t->expiry() + asio::chrono::milliseconds(333));
        t->async_wait(std::bind(&udp_server::udp_punch, this, t));
    }

    void start_receive()
    {
    socket.async_receive_from(
        asio::buffer(recv_buffer), remote_endpoint,
        std::bind(&udp_server::handle_receive, this,
            asio::placeholders::error,
            asio::placeholders::bytes_transferred));
    }

    void handle_receive(const std::error_code& error, std::size_t /*bytes_transferred*/) 
    {
        if (!error)
        {            
            std::string msg(recv_buffer.data());
            
            
            bool is_empty = true;
            
            for(int m{}; m<msg.size(); ++m) {
                if (msg[m] != 0 && msg[m] != ' ')   is_empty = false;
            }
            
            
            if(!is_empty) {
                save_message(selected_user, msg, "friend");
                std::cout<<"message received\n message: "<<msg<<std::endl;
            }
            
            std::fill_n(recv_buffer.begin(), 512, 0);
            start_receive();
        }
    }

    void send(std::string msg) {
        // std::array<char, 512> arr{};

        // for(int i{}; i<msg.size() && i<512; ++i) {
        //     arr[i] = msg[i];
        // }

        auto msg_ptr = std::make_shared<std::string>(std::move(msg));

        socket.async_send_to(
            asio::buffer(*msg_ptr), 
            send_endpoint,
            std::bind(
                &udp_server::handle_send, this, 
                asio::placeholders::error,
                asio::placeholders::bytes_transferred
            )
        );
    }

    void sync_send(std::string msg) {
        socket.send_to(
            asio::buffer(msg), 
            send_endpoint
        );
    }

    void handle_send(
        const std::error_code& /*error*/,
        std::size_t /*bytes_transferred*/
    ) {
        
    }
};



class tcp_connection
  : public std::enable_shared_from_this<tcp_connection>
{
public:
    typedef std::shared_ptr<tcp_connection> pointer;

    tcp::socket socket_;
    std::string message_;

    std::array<char, 4096> buffer;

    udp_server * udp_connection1;

    static pointer create(asio::io_context& io_context, udp_server * udp_c1)
    {
        return pointer(new tcp_connection(io_context, udp_c1));
    }

    tcp::socket& socket()
    {
        return socket_;
    }

    void start()
    {
        message_ = read_file(qindex);

        socket_.async_read_some(
            asio::buffer(buffer),
            std::bind(
                &tcp_connection::handle_read, shared_from_this(),
                asio::placeholders::error,
                asio::placeholders::bytes_transferred
            )
        );

    }

    void handle_read(const std::error_code& error, size_t bytes) {
        if (error) return;

        std::string client_ip = socket_.remote_endpoint().address().to_string();
        std::string request(buffer.data(), bytes);

        // sprawdź pierwszą linię requestu
        if (request.find("GET /time") != std::string::npos) {
            // request o godzinę
            std::cout << "GET /time from: " << client_ip << "\n";
            time_t now = time(0);
            std::string t = ctime(&now);
            t.erase(t.find_last_not_of("\n") + 1); // usuń newline
            message_ = make_http_response(t, "text/plain");
        } else if (request.find("GET /style.css") != std::string::npos) {
            // request o css
            std::cout << "GET /style.css from: " << client_ip << "\n";
            message_ = make_http_response(read_file(style), "text/css");
        } else if (request.find("GET /icon.ico") != std::string::npos) {
            // request o ikone
            std::cout << "GET /icon.ico from: " << client_ip << "\n";
            message_ = make_http_response(read_file(icon), "image/x-icon");
        } else if (request.find("GET /logo.jpg") != std::string::npos) {
            // request o ikone
            std::cout << "GET /logo.jpg from: " << client_ip << "\n";
            message_ = make_http_response(read_file(logo), "image/jpeg");
        } else if (request.find("GET /profile_picture.jpg") != std::string::npos) { ///////////////////////////////////
            // request o ikone
            std::cout << "GET /profile_picture.jpg from: " << client_ip << "\n";
            message_ = make_http_response(read_file(profile_picture), "image/jpeg");
        } else if (request.find("GET /pfps/") != std::string::npos) {

            // request o profile picture do specific usera
            std::string requested_uuid = request.substr(request.find("GET /pfps/") + 10, 36);
            std::cout << "GET /pfps/"<<requested_uuid<<" from: "<< client_ip <<"\n";
            message_ = make_http_response(read_file("./friends/"+requested_uuid+"/profile_picture.jpg"), "image/jpeg");
        } else if (request.find("GET /select_user/") != std::string::npos) {

            // request o profile picture do specific usera
            std::string requested_uuid = request.substr(request.find("GET /select_user/") + 17, 36);
            std::cout << "GET /select_user/"<<requested_uuid<<" from: "<< client_ip <<"\n";

            selected_user = requested_uuid;

            std::string ip_addr = "";
            int iport, oport;

            std::ifstream ip_io_file("./friends/"+selected_user+"/ip_io");

            ip_io_file >> ip_addr;
            ip_io_file >> iport;
            ip_io_file >> oport;

            ip_io_file.close();

            udp_connection1->change_target(iport, oport, ip_addr);

            message_ = make_http_response("ok", "text/plain");

        } else if (request.find("GET /messages/") != std::string::npos) {
            // request o wiadomości do specific usera
            std::string requested_uuid = request.substr(request.find("GET /messages/") + 14, 36);
            std::cout << "GET /messages/"<<requested_uuid<<" from: "<< client_ip <<"\n";
            message_ = make_json_messages(requested_uuid);

        } else if (request.find("GET /friend_list") != std::string::npos) {
            // request o listę znajomych
            // std::string requested_uuid = request.substr(request.find("GET /messages/") + 14, 36);
            std::cout << "GET /friend_list from: "<< client_ip <<"\n";
            message_ = make_json_friends();
            
        } else if (request.find("POST /send/") != std::string::npos) {

            
            std::string requested_uuid = request.substr(request.find("POST /send/") + 11, 36);
            std::string body = request.substr(request.find("\r\n\r\n") + 4);
            
            std::cout<<"GET /send/uuid "<<client_ip<<" is sending message to "<<requested_uuid<<"\n";
            
            // wyciągnij message z JSON {"message":"treść"}
            std::string message = body.substr(body.find("\"message\":\"") + 11);
            message = message.substr(0, message.find("\""));
            
            save_message(requested_uuid, message, "you");
            udp_connection1->send(message);
            
            message_ = make_http_response("ok", "text/plain");
        } else {
            // domyślnie wyślij index.html
            std::cout << "GET / from: " << client_ip << "\n";
            message_ = make_http_response(prepare_html(read_file(qindex)), "text/html");
        }

        asio::async_write(socket_, asio::buffer(message_),
            std::bind(&tcp_connection::handle_write, shared_from_this(),
                asio::placeholders::error,
                asio::placeholders::bytes_transferred)
        );
    }

    tcp_connection(asio::io_context& io_context, udp_server * udp_c1)
    : socket_(io_context), udp_connection1(udp_c1)
    {

    }

    void handle_write(const std::error_code& /*error*/,
    size_t /*bytes_transferred*/)
    {

    }
    
    
};

class http_server
{
public:
    asio::io_context& io_context_;
    tcp::acceptor acceptor_;

    udp_server * udp_connection1;

    http_server(asio::io_context& io_context, udp_server * udp_s)
    : io_context_(io_context), udp_connection1(udp_s),
    acceptor_(io_context, tcp::endpoint(
        //tcp::v4() //opened to everyone in the network
        asio::ip::make_address("127.0.0.1"), //opened only to this computer
        client_port)
    ) {
        start_accept();
    }


    void start_accept()
    {
        tcp_connection::pointer new_connection =
            tcp_connection::create(io_context_, udp_connection1);
        
        acceptor_.async_accept(new_connection->socket(),
            std::bind(
                &http_server::handle_accept, this, new_connection,
                asio::placeholders::error)
            );
    }

    void handle_accept(
        tcp_connection::pointer new_connection,
        const std::error_code& error
    )
    {
        if (!error)
        {
            new_connection->start();
        }

        start_accept();
    }

};









int main(int argc, char const *argv[])
{

    uuid = read_file("./user_settings/uuid.txt");

    asio::io_context io;

    

    
    
    
    std::string ip_io = "./friends/"+selected_user+"/ip_io";
    std::ifstream ip_file(ip_io);
    std::string target_ip;
    int iport, oport;
    ip_file >> target_ip;
    ip_file >> iport;
    ip_file >> oport;
    std::cout<<iport<<std::endl<<oport<<std::endl<<target_ip<<std::endl;
    ip_file.close();
    
    


    udp_server udp_connection1(io, iport, oport, target_ip);
    http_server http_server(io, &udp_connection1);



    io.run();


    return 0;
}